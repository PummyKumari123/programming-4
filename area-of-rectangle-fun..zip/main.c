/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
int rectanglearea(int a,int b);
int main()
{
    int area,a,b;
    printf("print two nos.");
scanf("%d%d",&a,&b);
area=rectanglearea(a,b);
printf("area of rectangle is %d",area);

    return 0;
}
int rectanglearea(int a,int b){
    int area;
    area=a*b;
    return area;
}

