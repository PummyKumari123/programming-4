/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int i,n,a[1000],x,pos;
    printf("no. of element do u want ti print  ");
    scanf("%d",&n);
    printf("enter elements: ");
for(i=0;i<n;i++){
scanf("%d",&a[i]);
}
for(i=0;i<n;i++){
    printf("%d\n",a[i]);
}
printf("insert element is ");
scanf("%d",&x);
printf("which position do u want to insert ");
scanf("%d",&pos);

n++;
for(i=n-1;i>=pos;i--){
    a[i]=a[i-1];}
a[pos-1]=x;
for(i=0;i<n;i++){
    printf("%d\t",a[i]);}
    return 0;
}

