/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
int factorial(int num);
int main()
{
    int fact,num; 
    printf("enter no. of which u want");
    scanf("%d",&num);
    fact=factorial(num);
    printf(" the factorial of %d is %d",num,factorial(num));
    

    return 0;
}
int factorial(int num){
    int fact;
    if(num==1||num==0)
    return 1;
    else
    
    return (num*factorial(num-1));
}

