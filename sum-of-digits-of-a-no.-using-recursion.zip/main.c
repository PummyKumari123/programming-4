/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
int add(int num);
int main()
{
    int sum,num;
    printf("enter a 5 digit no.");
scanf("%d",&num);
sum=add(num);
printf("the sum is %d",sum);
    return 0;
}
int add(int num){
    int sum;
    while(num != 0){
    
    
    return (num%10+add(num/10));}
}




