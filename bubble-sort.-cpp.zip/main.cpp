/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    int i,j,n,a[100],temp;
    printf("enter the terms: ");
    cin>>n;
    for(i=0;i<n;i++) {
        cin>>a[i];}
        for(i=0;i<n-1;i++){
         for(j=0;j<n-1-i;j++) {
             if(a[j]>a[j+1]){
                 temp=a[j];
                 a[j]=a[j+1];
                 a[j+1]=temp; }
         }
        }
        for(i=0;i<n;i++){
    cout<<a[i]<<"\t";
        }

    return 0;
}

