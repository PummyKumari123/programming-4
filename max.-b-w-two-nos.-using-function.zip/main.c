/***********
 * ******************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
int max(int a, int b);
void main()
{
    int a,b,greatest;
    printf("enter two nos.");
scanf("%d%d",&a,&b);
greatest=max(a,b);
printf("max is %d",greatest);
    getch();
}
int max(int a,int b){

    
        return (a>b)? a:b;
        
}


