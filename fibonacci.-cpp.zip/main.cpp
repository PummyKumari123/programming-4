/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int a=0,b=1,c,n,i;
    cout<<"enter terms";
    cin>>n;
    printf("%d\t%d",a,b);
    for(i=1;i<=n-2;i++){ 
c=a+b;
printf("\t%d",c);
a=b;
b=c;
}

    return 0;
}